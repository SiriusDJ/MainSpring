package net.nvsoftware.iPaymentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
